import React from "react"
import { faCoffee, faMugSaucer, faCalendarDays, faLocationDot, faClock, faIdBadge , faEnvelopeOpen} from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import Header from "../component/header"
import style from "../css/careers.module.css"

export default function Careers() {
    return (
        <>
            <Header />
            <div className={style.careerjobpagewrapper}>
                <div className={`${style.currentrolesection} ${style.currentrolesection}`} id="currentrolesection">
                    <div className={style.container}>
                        <div className={`${style.textcenter}`}>
                            <h3>Current Roles</h3>
                            {/* <FontAwesomeIcon icon={faCoffee} /> */}
                            {/* <FontAwesomeIcon icon={['fab', 'twitter']} /> */}
                            {/* <FontAwesomeIcon icon="coffee" /> */}
                        </div>
                        <div className={`${style.currentrolesectiondescription} ${style.sectiondescription} ${style.textcenter}`}>
                            <p>We don’t currently have any open postings. Check back soon or join our Talent Network to be the first to know about new postings.
                                Check out these opportunities to join the Oshawa Power team!</p>
                        </div>
                        <div className={style.awsmjobwrap}>
                            <div className={`${style.awsmjoblistings} ${style.awsmrow} ${style.awsmgridcol2}`}>
                                <div id="awsmgriditem11547" className={` ${style.awsmgriditem}`} >
                                    <div className={style.awsmjobitem}> {/* card start */}
                                        <div className={style.awsmgridleftcol}>
                                            <h2 className={style.awsmjobposttitle}>JOURNEYPERSON POWERLINE TECHNICIAN</h2>
                                        </div>
                                        <div className={style.awsmgridrightcol}>
                                            <div className={style.awsmjobspecificationwrapper}>
                                                <div className={`${style.awsmjobspecificationitem} ${style.awsmjobspecificationjobshareemail}`}>
                                                    <a href="mailto:?body=Hi%0D%0A%0D%0AI like this job. You also like this. View this Job.%0D%0Ahttps://www.oshawapower.ca/jobs/journeypersonpowerlinetechnician/%0D%0A%0D%0A">
                                                        <i className={style.awsmjobiconenvelopeopen}></i>
                                                        <FontAwesomeIcon icon={faEnvelopeOpen} style={{ color: "#cc0633" }} size="2xs" />
                                                        <span className={style.awsmjobspecificationterm}>Share via email</span>
                                                    </a>
                                                </div>
                                                <div className={`${style.awsmjobspecificationitem} ${style.awsmjobspecificationjobdate}`}>
                                                    <FontAwesomeIcon icon={faCalendarDays} className={style.awsmjobiconcalendar} style={{ color: "#cc0633" }} size="2xs" />
                                                    <span className={style.awsmjobspecificationterm}>28th June, 2024</span>
                                                </div>
                                                <div className={`${style.awsmjobspecificationitem} ${style.awsmjobspecificationjoblocation}`}>
                                                    <FontAwesomeIcon icon={faLocationDot} style={{ color: "#cc0633" }} size="2xs"/>
                                                    <span className={style.awsmjobspecificationterm}>Anywhere</span>
                                                </div>
                                                <div className={`${style.awsmjobspecificationitem} ${style.awsmjobspecificationjobtype}`}>
                                                    <FontAwesomeIcon icon={faClock} style={{ color: "#cc0633" }} size="2xs"/>
                                                    <span className={style.awsmjobspecificationterm}>Full Time</span>
                                                </div>
                                                <div className={`${style.awsmjobspecificationitem} ${style.awsmjobspecificationjobcompanyname}`}>
                                                   
                                                    <span className={style.awsmjobspecificationterm}>  <FontAwesomeIcon icon={faIdBadge} style={{ color: "#cc0633" }} size="2xs"/>OPUC</span>
                                                </div>
                                            </div>
                                            <div className={style.awsmjobmorecontainer}>
                                                <span className={style.awsmjobmore}>More Details</span>
                                            </div>
                                        </div>
                                    </div> {/* card close */}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
