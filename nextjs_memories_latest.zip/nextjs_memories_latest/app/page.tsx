import Image from "next/image";
import { documentToReactComponents } from '@contentful/rich-text-react-renderer';
import { BLOCKS } from "@contentful/rich-text-types"; 
import styles from "./page.module.css";
import Link from 'next/link';
import Head from 'next/head';
import Header from "./component/header";
import { getPageData } from "@/lib/getPageData";  
import { getMemoriesData } from '@/lib/getMemoriesData';

export default async function Home() {
  let pageData = await getPageData('home-page');
  console.log('get page data..');
  console.log('page data', pageData.description.json);

  const data = await getMemoriesData();
  console.log('-----------------------------------');

  const options = {
    renderNode: {
      [BLOCKS.PARAGRAPH]: (node: any, children: any) => {
        if (children.length === 0) {
          return <br />;
        } else {
          return <p>{children}</p>;
        }
      } ,
      [BLOCKS.HEADING_1]: (node: any, children: any) => <h1>{children}</h1>,
      [BLOCKS.HEADING_2]: (node: any, children: any) => <h2>{children}</h2>,
      [BLOCKS.HEADING_3]: (node: any, children: any) => <h3>{children}</h3>,
      [BLOCKS.HEADING_4]: (node: any, children: any) => <h4>{children}</h4>,
      [BLOCKS.HEADING_5]: (node: any, children: any) => <h5>{children}</h5>,
      [BLOCKS.HEADING_6]: (node: any, children: any) => <h6>{children}</h6>,
      [BLOCKS.QUOTE]: (node: any, children: any) => <blockquote>{children}</blockquote>,
      [BLOCKS.UL_LIST]: (node: any, children: any) => <ul>{children}</ul>,
      [BLOCKS.OL_LIST]: (node: any, children: any) => <ol>{children}</ol>,
      [BLOCKS.LIST_ITEM]: (node: any, children: any) => <li>{children}</li>,
      [BLOCKS.HR]: () => <hr />,
    },
  };

  return (
    <div className={styles.container}>
      <Head>
        <title>{pageData?.title}</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <main className={styles.main}>
        <Header /> 
        {/* {pageData?.banner?.url && (
          <Image 
            src={pageData?.banner?.url} 
            alt={pageData?.banner?.title} 
            width={1200} 
            height={600} 
            layout="responsive"
          />
        )} */}
        <h1 className={styles.title}>{pageData?.title}</h1>
        <div className={styles.content}>
          {documentToReactComponents(pageData?.description?.json, options)}
        </div>

        <ul>
          {data?.map((memory: any) => (
            <li key={memory.slug}>
              <Link href={`/memory/${memory.slug}`}>
                {memory.title}
              </Link>
            </li>
          ))}
        </ul>
      </main>  
    </div>
  );
}
