'use client'
import React, { useEffect, useState } from 'react';
const page = () => {
    const [data, setData] = useState(null);
    const [error, setError] = useState(null);
  
    useEffect(() => {
     /*  fetch('https://your-wordpress-site.com/wp-json/') */
    fetch('http://opuccorps.wpengine.com/wp-json/contact-form-7/v1/contact-forms/139/feedback/schema')
    //fetch('http://www.oshawapower.ca/wp-json/contact-form-7/v1/contact-forms/139/feedback/schema')
        .then(response => {
          if (!response.ok) {
            throw new Error('Network response was not ok');
          }
          return response.json();
        })
        .then(data => setData(data))
        .catch(error => setError(error.toString()));
    }, []);
  
    if (error) {
      return <div>Error: {error}</div>;
    }
  
    if (!data) {
      return <div>Loading...</div>;
    }

  return (
    <div>
      <h1>Fetched Data</h1>
      <pre>{JSON.stringify(data, null, 2)}</pre>
    </div>
  )
};

export default page
