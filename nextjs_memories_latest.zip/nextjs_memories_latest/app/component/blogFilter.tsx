import React from 'react';
import style from '../css/blogFilter.module.css'

const blogFilter = ({ tagData, tagEvent , categoryData , catEvent, andorEvent, totalData} :any) => {
/*   console.log('category filter new');
  console.log(categoryData); 
  console.log(tagData);  */
  return (
    <>
    <div className={style.tag_filter}>
      <h3>Filter by Tags</h3>
      {tagData.map((tag:any, index:any) => (
        <div key={index}>
          <input
            type="checkbox"
            id={`tag-${index}`}
            value={tag.tags}
            onChange={tagEvent}
          />
          <label htmlFor={`tag-${index}`}> {tag.tags} </label>
        </div>
      ))}
      </div>
       <div className='category-filter right-side-filter'>
       <h3>Filter by Categories</h3>
       
       {categoryData.map((cat:any,i:any)=>(
         
         <div key={i}>
          <input
            type="checkbox"
            id={`tag-${i}`}
            value={cat.blogcategory}
            onChange={catEvent}
          />
          <label htmlFor={`tag-${i}`}> {cat.blogcategory} </label>
        </div>
       ))}
       
    </div>
    <div className='category-filter right-side-filter'> 
      <input type='radio'name="both_comman" value="OR" onClick={andorEvent}/>Get the Both &nbsp;
      <input type='radio'name="both_comman" value="AND" onClick={andorEvent}/>Get the common
    </div>
    {
     totalData ?
      <div className={style.total_post_count}>Total post found <span className={style.total_post_numbr } > {totalData} </span></div>
      : <div className={style.no_post}> no post found </div>
    }
    
    </>
  );
};

export default blogFilter;
