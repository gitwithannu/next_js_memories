import Link from "next/link";
export default function Header(props:any) {
      console.log('Header section');
      console.log(props.banner);
    return (
      <header>
       {/*  <img src={props.banner} alt={props.title} /> */}
       <Link href="/"> Home </Link>
       <Link href="/blog"> Blog </Link>
       <Link href="/careers"> careers </Link>
      </header>
    );
  }
  