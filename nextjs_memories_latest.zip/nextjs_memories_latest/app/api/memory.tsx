export async function getSingleMemoriesBySlugNot(slug:any){
    // console.log('pass slug data');
    // console.log(slug);
    // console.log(process.env.NEXT_PUBLIC_CONTENTFUL_SPACE_ID);
    const result = await fetch(
        `https://graphql.contentful.com/content/v1/spaces/${process.env.NEXT_PUBLIC_CONTENTFUL_SPACE_ID}/environments/dev`,
        {
        method: 'POST',
        headers: {
            Authorization: `Bearer ${process.env.NEXT_PUBLIC_CONTENTFUL_ACCESS_TOKEN}`,
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            query: `
            query {
                 memoryCollection(where:{slug:"${slug}"}) {     
                items{
                  title
                  description
                  slug
                }
            
              }
            }
            `,
        }),
        },
    );
    if (!result.ok) {
        // console.log(' slug error showing');
        // console.error(result,'tesetses');
        // return {};
      }
    console.log(result)
      const { data } = await result.json();
      console.log(data);
      const memories = data?.memoryCollection?.items;
    //   console.log(result?.memories);
    //   console.log('testing value');
      return {
        props: {
          memories,
        },
      };


}