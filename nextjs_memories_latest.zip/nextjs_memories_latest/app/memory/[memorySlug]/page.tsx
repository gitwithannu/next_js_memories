
import { getSingleMemoriesBySlug } from '@/lib/getMemoriesData'; 
//import { getSingleMemoriesBySlug } from '@/app/api/memory';
export default async function MemoryPage({params}:any) {

    // console.log(params.memorySlug, 'ytyyyty');
    const SingleResult  = await getSingleMemoriesBySlug(params.memorySlug);
    
   // console.log(SingleResult[0].title)   
    return(
        <section>        
        <div>
            <h1>  { SingleResult[0].title  } </h1>
            <p>  { SingleResult[0].description } </p> 
        </div>                                     
        </section>
       
    )

}