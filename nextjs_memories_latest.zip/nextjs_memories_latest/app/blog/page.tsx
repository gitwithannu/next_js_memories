'use client';
import { useState, useEffect } from 'react';
import { getDefaultPost , getBlogCategory } from '@/lib/getBlogData';
import { getTags } from '@/lib/getTagsData';
import Cards from '../component/cards';
import BlogFilter from '../component/blogFilter';
import Header from '../component/header';

export default function Blog() {
  // State for posts and tags
  const [posts, setPosts] = useState([]);
  const [tags, setTags] = useState([]);
  const [filtertag , setFiltertag]  = useState([]);
  const [category, setCategory] = useState([]);
  const [filtercate, setFiltercate] = useState([]);
  const [andor ,setAndor] = useState('');
  const [totalpost, setTotalpost] = useState();

  function onClickTagHandler(event:any){
    // /* console.log('testing Event ');
    // console.log(event.target.value);
   let tagselect =  event.target.value;
    setFiltertag((prevSelectedTags:any) =>
      prevSelectedTags.includes(tagselect)
        ? prevSelectedTags.filter((t:any) => t !== tagselect)
        : [...prevSelectedTags, tagselect]
    );   
  }

  function onClickCateHandler(event:any){
    let cateselect = event.target.value;
    console.log(cateselect);
     setFiltercate((preSelectedCate:any)=>
      preSelectedCate.includes(cateselect)
      ? preSelectedCate.filter((c:any)=> c !== cateselect )
      : [...preSelectedCate, cateselect]
     )
  }
  function onClickAndOrHandler(event:any){ 
    console.log(event.target.value);
    setAndor(event.target.value);
    
  }

  // useEffect to fetch data on component mount
  useEffect(() => { 
    const fetchData = async () => {
      try {
        const postResult = await getDefaultPost({'tags':filtertag,'category':filtercate ,'andor':andor});
        const tagsResult = await getTags();
        const blogCategory  = await getBlogCategory();
        /* console.log(blogCategory);
        console.log('test cate'); */
        setPosts(postResult.items);
        setTags(tagsResult);
        setCategory(blogCategory)
        setTotalpost(postResult.items.length)
        
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    fetchData();
  }, [filtertag, filtercate, andor]); // Empty dependency array ensures this runs once on mount
  return (
    <>
        <Header /> 
      <h1>Blog Page</h1>
      <BlogFilter tagData={tags} tagEvent={onClickTagHandler} categoryData={category} catEvent={onClickCateHandler} andorEvent={onClickAndOrHandler}  totalData={totalpost}/>
       
      {posts.map((blog,i) => (
        <Cards key={i} data={blog}  />
      ))}
    </>
  );
}
