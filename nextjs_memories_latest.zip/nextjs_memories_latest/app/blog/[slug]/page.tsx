import Header from "@/app/component/header";
import { getBlogBySlug } from "@/lib/getBlogData";
const page = async ({params}:any) => {
    console.log('blog details page-');
    console.log(params.slug)
    const fetchBlogDetails = await getBlogBySlug(params.slug);
    console.log(fetchBlogDetails);
  return (
    <div>
        <Header/>
      single blog page
    </div>
  )
};

export default page
