import graphqlClient from "./graphqlClient";
export async function getDefaultPost(filterpram:any){
 console.log(filterpram.andor);
 var tag = '';
 var cat ='';
 let condition  = 'AND';

   condition  = filterpram.andor ? filterpram.andor : 'AND'


 if(filterpram.tags.length > 0){
   tag =`
    { blogTags: { tags_in: [${filterpram?.tags?.map((tag:any) => `"${tag}"`).join(', ')}] } } `
  
 }
  if(filterpram.category.length > 0){
  cat =` 
     { category: { blogcategory_in: [${filterpram?.category?.map((cate:any) => `"${cate}"`).join(', ')}] } }  `
 
} 
    var query = `
    query {
        blogPostCollection ( limit:20 where: { ${condition} : [
          ${tag}
          ${cat}
         ]}){
            items{
              title   
              slug
              excerpt{
                json
              }
               blogTagsCollection{
                items{
                  tags
                }
              }
              categoryCollection {
                items {
                  blogcategory
                }
              }
          
            }
          }  
        }
       `
       console.log(query,'111111');
   var result = await graphqlClient(query); 
  // console.log(result);
   if (result.props.blogPostCollection.items[0] !== 0) {
    return result?.props?.blogPostCollection;
  }
  else {    
      return ;   
  }

}

export async function checkOPUC(){
  fetch('https://your-wordpress-site.com/wp-json/')
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(error => console.error('Error:', error));
}

export async function getBlogCategory(){  
  var query = `
  query {    
      blogCategoryCollection{
        items{
          blogcategory
        }
      }    
  }`
  var cate_result = await graphqlClient(query); 
  return cate_result.props.blogCategoryCollection.items ? cate_result.props.blogCategoryCollection.items : "";

}

export async function getBlogBySlug(slug:any){
   console.log('getBlogBySlug', slug);
}