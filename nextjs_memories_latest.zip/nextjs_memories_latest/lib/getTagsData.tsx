import graphqlClient from "./graphqlClient";

export async function getTags(){
    var query = `
    query {
        tagCollection{
            items{
              tags
            }
          } 
        }
       `

   var result = await graphqlClient(query); 
   // console.log('tagData graph query ');
   //console.log(result.props.tagCollection.items);
   return result.props.tagCollection.items ? result.props.tagCollection.items : "";
}