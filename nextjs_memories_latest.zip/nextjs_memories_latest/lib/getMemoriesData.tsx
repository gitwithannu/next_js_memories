import graphqlClient from "./graphqlClient";

/* export async function getMemoriesData(){
        const result = await fetch(
            `https://graphql.contentful.com/content/v1/spaces/${process.env.NEXT_PUBLIC_CONTENTFUL_SPACE_ID}/environments/dev`,
            {
                method: 'POST',
                headers: {
                    Authorization: `Bearer ${process.env.NEXT_PUBLIC_CONTENTFUL_ACCESS_TOKEN}`,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    query: `
                    query {
                        memoryCollection {
                        items {
                            title
                            slug
                            description
                        }
                        }
                    }
                    `,
                }),
            },
        );
    
      if (!result.ok) {
         console.error(result);
        return {};
      }
    
      const { data } = await result.json();
      const memories = data.memoryCollection.items;
    //   console.log(result.memories);
    //   console.log('testing value');
      return {
        props: {
          memories,
        },
      };
}
export async function getSingleMemoriesBySlug(slug:string | string[]){
    const result = await fetch(
        `https://graphql.contentful.com/content/v1/spaces/${process.env.NEXT_PUBLIC_CONTENTFUL_SPACE_ID}/environments/dev`,
        {
        method: 'POST',
        headers: {
            Authorization: `Bearer ${process.env.NEXT_PUBLIC_CONTENTFUL_ACCESS_TOKEN}`,
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            query: `
            query {
                 memoryCollection(where:{slug:"${slug}"}) {     
                items{
                  title
                  description
                  slug
                }
            
              }
            }
            `,
        }),
        },
    );
    if (!result.ok) {
         console.log(' slug error showing');
         return {};
      }
      const { data } = await result.json();
      const memories = data?.memoryCollection?.items;
      return {
        props: {
          memories,
        },
      };
} */

export async function getMemoriesData(){
  var query = `
  query {
    memoryCollection {
        items {
          title
          slug
          description
        }
       }
      }
     `
   var result  = await graphqlClient(query);
   // console.log(result?.props?.response?.memoryCollection);
   if (result.props.memoryCollection.items.length !== 0) {
    return result.props.memoryCollection.items;
  }
    else {
      return ;
  }

}
export async function getSingleMemoriesBySlug(slug:string | string[]){
    var query  = `
      query {
            memoryCollection(where:{slug:"${slug}"}) {     
          items{
            title
            description
            slug
          }
      
        }
      }`;

  var result  = await graphqlClient(query);
  //console.log(result.props.memoryCollection.items);
  if (result.props.memoryCollection.items.length !== 0) {
    return result.props.memoryCollection.items;
  }
  else {
    return ;
  }
  
/*   return {
    props: {
      memories: result.props?.response.memoryCollection.items
    },
  } */

 /*    if (!result.ok) {
       console.log(' slug error showing');
       return {};
    }
    const { data } = await result.json();
    const memories = data?.memoryCollection?.items; 
    return {
      props: {
        memories,
      },
    }; */
}