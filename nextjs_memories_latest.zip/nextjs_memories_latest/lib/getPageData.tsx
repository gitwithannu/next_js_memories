import graphqlClient from "./graphqlClient";
export  async function getPageData(slug:string){
  var query = `
  query {
        pagesCollection(limit:1, where:{slug:"${slug}"} ){
          items{
            title
            slug
            banner{
              url
              title
            }
            description {
              json
            }
          }
        }   
      }
     `
   var result  = await graphqlClient(query);
   
   // console.log(result?.props?.response.pagesCollection.items[0])
   //return result?.props?.response.pagesCollection.items ;
/*     return{
    props:{
       page: result?.props?.pagesCollection.items[0]
     }
   }  */
   if (result?.props?.pagesCollection.items[0] !== 0) {
    return result?.props?.pagesCollection.items[0];
  }
    else {
      return ;
  }

}

/* export  async function getPageData(slug:string){
    console.log(slug);
  const result = await fetch(`https://graphql.contentful.com/content/v1/spaces/${process.env.NEXT_PUBLIC_CONTENTFUL_SPACE_ID}/environments/dev`,{
    method: 'POST',
    headers: {
        Authorization: `Bearer ${process.env.NEXT_PUBLIC_CONTENTFUL_ACCESS_TOKEN}`,
        'Content-Type': 'application/json',
    },
    body: JSON.stringify({
        query: `
        query {
            pagesCollection(limit:1, where:{slug:"${slug}"} ){
                items{
                  title
                  slug
                  banner{
                    url
                    title
                  }
                  description {
                    json
                  }
                }
              }
        }
        `,
    }),
  }
  
  )
  if (!result.ok) {
    console.error(result);
   return {};
  }

 const { data } = await result.json();
 //console.log(data.pagesCollection.items);
 //const memories = data.memoryCollection.items;
 return{
    props:{
       page: data.pagesCollection.items
    }
 }

} */