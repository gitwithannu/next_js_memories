export default  async function graphqlClient(queryData:any){
   // console.log(queryData);
  const result = await fetch(`https://graphql.contentful.com/content/v1/spaces/${process.env.NEXT_PUBLIC_CONTENTFUL_SPACE_ID}/environments/dev`,{
    method: 'POST',
    headers: {
        Authorization: `Bearer ${process.env.NEXT_PUBLIC_CONTENTFUL_ACCESS_TOKEN}`,
        'Content-Type': 'application/json',
    },
    body: JSON.stringify({
        query: queryData,
    }),
  }
  
  )
  if (!result.ok) {
    console.log('Error Message : ');
    //console.error(result);
   return {};
  }

 const { data } = await result.json();
 //console.log(data);
 const pageresult = data;
 //const memories = data.memoryCollection.items;
/*  return{
    props:{
       page: data.pagesCollection.items
    }
 } */
 return{
    props: data
    
 }
 

}